<?php 
include "../inc/session.php";
// include "../inc/admin_check.php";
?>

<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>공지사항</title>
    <style>
        body,input,button,select,option{font-size:20px}
        input[type=checkbox]{width:20px;height:20px}
        input[type=radio]{width:20px;height:20px}
    </style>
    <script>
        function notice_check(){
            var u_name = document.getElementById("u_name");
            var u_id = document.getElementById("u_id");

            if(!u_name.value){
                alert("이름을 입력하세요.");
                u_name.focus();
                return false;
            };

            if(!u_id.value){
                alert("아이디를 입력하세요.");
                u_id.focus();
                return false;
            };

        };

    </script>
</head>
<body>
    <form name="notice_form" action="insert.php" method="post" onsubmit="return notice_form_check()">
        <fieldset>
            <legend>공지사항</legend>

            <p>
                작성자 <?php echo $s_name; ?>
            </p>
            <p>
                <label for="n_title">제목</label>
                <input type="text" name="n_title" id="n_title">
            </p>
            <p>
                <label for="pwd">내용</label>
                <textarea cols="60" rows="10" name="n_content" id="n_content"></textarea>
            </p>
            <p>
                <button type="button" onclick="history.back()"> 이전 페이지 </button>
                <button type="submit"> 등록하기 </button>
            </p>
        </fieldset>
    </form>
</body>
</html>
<?php

include "../inc/session.php";

// DB 연결
include "../inc/dbcon.php";

// 쿼리 작성
// $sql = "select * from notice;";
$sql = "select * from notice;";

// 쿼리 전송
$result = mysqli_query($dbcon, $sql);

// 전체 데이터 가져오기
$total = mysqli_num_rows($result);

// paging : 한 페이지 당 보여질 목록 수
$list_num = 5;

// paging : 한 블럭 당 페이지 수
$page_num = 3;

// paging : 현재 페이지
// $page = $_GET["page"];
$page = isset($_GET["page"])? $_GET["page"] : 1;

// paging : 전체 페이지 수 = 전체 데이터 / 페이지 당 목록 수,  ceil : 올림값, floor : 내림값, round : 반올림
$total_page = ceil($total / $list_num);
// echo "전체 페이지수 : ".$total_page;
// exit;

// paging : 전체 블럭 수 = 전체 페이지 수 / 블럭 당 페이지 수
$total_block = ceil($total_page / $page_num);

// paging : 현재 블럭 번호 = 현재 페이지 번호 / 블럭 당 페이지 수
$now_block = ceil($page / $page_num);

// paging : 블럭 당 시작 페이지 번호 = (해당 글의 블럭 번호 - 1) * 블럭 당 페이지 수 + 1
$s_pageNum = ($now_block - 1) * $page_num + 1;
if($s_pageNum <= 0){
    $s_pageNum = 1;
};

// paging : 블럭 당 마지막 페이지 번호 = 현재 블럭 번호 * 블럭 당 페이지 수
$e_pageNum = $now_block * $page_num;
// 블럭 당 마지막 페이지 번호가 전체 페이지 수를 넘지 않도록
if($e_pageNum > $total_page){
    $e_pageNum = $total_page;
};

?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> 공지사항 </title>
    <style>
        body{font-size:20px}
        a{text-decoration:none;margin:0 5px}

        table, td{
            border-collapse:collapse;
        }
        th{
            width: 150px;
            padding:10px;
            font-size:16px;
            text-align:center;
            background-color: skyblue;
        }
        td{
            width: 700px;
            padding:10px;
            font-size:16px;
            text-align:center;
        }
        .notice_list_set .pager{
            width:860px
        }
        .notice_list_title{
            border-top:2px solid #999;
            border-bottom:1px solid #999
        }
        .notice_view_content{
            border-bottom:1px solid #999;
        }
        .no{width:60px}
        .n_title {
            width: 500px;
        }
        .list {
            width: 860px;
            text-align:centerl
        }

        table a:hover{color:rgb(255, 128, 0)}
        </style>
        <?php if ($s_id == "admin" ) { ?>
    <style>
        .write_area {
            width: 860px;
            display:flex;
            justify-content:space-between;
            flex-direction: row-reverse;
            
        }
    </style>
        <?php } ?>
</head>

<body>
    <?php include "../admin/inc/sub_header.html" ?>
    
    <!-- 콘텐트 -->
    <h2>공지사항</h2>
    <?php if ($s_id == "admin" ) { ?>
    <p class= "write_area">
    <span> <a href="write.php"> 글쓰기 </a> <?php echo $total; ?>개</span>
    <?php } ?>
    
    <table class="notice_list_set">
        <tr class="notice_list_title">
            <th class="v_title">제목</th>
            <td class="v_content">값</td>
        </tr>

        <tr class="notice_view_content">
            <th class="v_title">작성자</th>
            <td class="v_content">값</td>
        </tr>

        <tr class="notice_view_content">
            <th class="v_title">날짜</th>
            <td class="v_content">값</td>
        </tr>

        <tr class="notice_view_content">
            <th class="v_title">조회수</th>
            <td class="v_content">값</td>
        </tr>

        <tr class="notice_view_content">
            <td colspan="2" class="v_text">값</td>
        </tr>
    </table>
    <p class="list">
        <a href="list.php">[목록]</a>
    </p>

</body>

</html>